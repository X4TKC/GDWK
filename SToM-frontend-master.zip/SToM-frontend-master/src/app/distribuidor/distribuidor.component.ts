import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-distribuidor',
  templateUrl: './distribuidor.component.html',
  styleUrls: ['./distribuidor.component.css']
})
export class DistribuidorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
