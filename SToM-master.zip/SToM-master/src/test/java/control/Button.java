package control;

import org.openqa.selenium.By;

public class Button extends Control {

    public Button(By customLocator){
        this.locator = customLocator;
    }

}
